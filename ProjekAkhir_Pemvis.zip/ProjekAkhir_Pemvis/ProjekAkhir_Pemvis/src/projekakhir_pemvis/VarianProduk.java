/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projekakhir_pemvis;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author EBC KOMPUTER
 */
public class VarianProduk {
    private int id;
    private int id_produk;
    private String atribut_nama;
    private String atribut_nilai;
    private int stok;
    
    public VarianProduk(int id, int id_produk, String atribut_nama, String atribut_nilai, int stok) {
        this.id = id;
        this.id_produk = id_produk;
        this.atribut_nama = atribut_nama;
        this.atribut_nilai = atribut_nilai;
        this.stok = stok;

    }
    public static List<VarianProduk> getVaProById_produk(int id_produk) {
        List<VarianProduk> list = new ArrayList<>();
        String query = "SELECT * FROM varian_produk WHERE id_produk = ?";
        
        try (
            Connection connection = Koneksi.getConnection();
            PreparedStatement stmt = connection.prepareStatement(query);
        ) {
            stmt.setInt(1, id_produk);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(new VarianProduk(
                    rs.getInt("id"), 
                    rs.getInt("id_produk"), 
                    rs.getString("atribut_nama"), 
                    rs.getString("atribut_nilai"), 
                    rs.getInt("stok")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return list;
    }
    
    public void tambahProduk(){
        String sql = "INSERT INTO varian_produk (id_produk, atribut_nama, atribut_nilai, stok) VALUES (?, ?, ?, ?)";
        try (Connection conn = Koneksi.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id_produk);
            ps.setString(2, atribut_nama);
            ps.setString(3, atribut_nilai);
            ps.setInt(4, stok);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
        } catch (SQLException e) {
            System.out.println("Error Save Data " + e.getMessage());
        }
    }
    
    public void editProduk(){
        String sql = "UPDATE varian_produk SET id_produk = ?, atribut_nama = ?, atribut_nilai = ?, stok = ? WHERE id = ?";
        try (Connection conn = Koneksi.getConnection();  
            PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setInt(1, id_produk);
            ps.setString(2, atribut_nama);
            ps.setString(3, atribut_nilai);
            ps.setInt(4, stok);
            ps.setInt(5, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Berhasil Diubah");
            
        } catch (SQLException e) {
            System.out.println("Error Save Data " + e.getMessage());
        }
    }

    public void hapusProduk(){
        String sql = "DELETE FROM varian_produk WHERE id = ?";
        try (Connection conn = Koneksi.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setInt(1, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");

        } catch (SQLException e) {
            System.out.println("Error Save Data " + e.getMessage());
        }
    }

    public String getAtribut_nilai() {
        return atribut_nilai;
    }

    public String getAtribut_nama() {
        return atribut_nama;
    }
    
    
}
