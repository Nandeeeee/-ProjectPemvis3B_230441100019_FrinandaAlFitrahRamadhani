/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projekakhir_pemvis;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author EBC KOMPUTER
 */
public class Pelanggan {
    private int id;
    private String nama;
    private String username;
    private int password;
    private String jenis_kelamin;
    private String alamat;
    private int no_hp;
    
    public Pelanggan(int id, String nama, String username, int password, String jenis_kelamin, String alamat, int no_hp) {
        this.id = id;
        this.nama = nama;
        this.username = username;
        this.password = password;
        this.jenis_kelamin = jenis_kelamin;
        this.alamat = alamat;
        this.no_hp = no_hp;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNama() {
        return nama;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setPassword(int password) {
        this.password = password;
    }

    public int getPassword() {
        return password;
    }

    public void setJenis_Kelamin(String jenis_kelamin) {
        this.jenis_kelamin = jenis_kelamin;
    }

    public String getJenis_Kelamin() {
        return jenis_kelamin;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setNo_Hp(int no_hp) {
        this.no_hp = no_hp;
    }

    public int getNo_Hp() {
        return no_hp;
    }
    
}
