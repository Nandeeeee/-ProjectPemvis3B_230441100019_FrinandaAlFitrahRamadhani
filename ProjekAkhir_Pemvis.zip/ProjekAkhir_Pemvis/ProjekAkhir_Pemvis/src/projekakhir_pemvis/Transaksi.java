/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projekakhir_pemvis;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author EBC KOMPUTER
 */
 public class Transaksi {
    private int id;
    private int id_user;
    private Date tgl_transaksi;
    private double total_harga;
    
    public Transaksi(int id, int id_user, Date tgl_transaksi, double total_harga) {
        this.id = id;
        this.id_user = id_user;
        this.tgl_transaksi = tgl_transaksi;
        this.total_harga = total_harga;
    }
    
    public static Transaksi getLastData() {
        Transaksi t = null; 
        String query = "SELECT * FROM transaksi ORDER BY id DESC LIMIT 1";
        
        try (
            Connection connection = Koneksi.getConnection();
            PreparedStatement stmt = connection.prepareStatement(query);
        ) {
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                t = new Transaksi(
                    rs.getInt("id"), 
                    rs.getInt("id_user"), 
                    rs.getDate("tgl_transaksi"), 
                    rs.getDouble("total_harga")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return t;
    }
    
    public static boolean tambah(int id_user, double total_harga) {
        String sql = "INSERT INTO transaksi (id_user, tgl_transaksi, total_harga) VALUES ( ?, ?, ?)";
        java.sql.Date currentDate = new java.sql.Date(System.currentTimeMillis());
        try (Connection conn = Koneksi.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id_user);
            ps.setDate(2, currentDate);
            ps.setDouble(3, total_harga);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
            return true;
        } catch (SQLException e) {
            System.out.println("Error Save Data " + e.getMessage());
        }
        return false;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId_User(int id_user) {
        this.id_user = id_user;
    }

    public int getId_User() {
        return id_user;
    }

    public void setTgl_Transaksi(Date tgl_transaksi) {
        this.tgl_transaksi = tgl_transaksi;
    }

    public Date getTgl_Transaksi() {
        return tgl_transaksi;
    }

    public void setTotal_Harga(double total_harga) {
        this.total_harga = total_harga;
    }

    public double getTotal_Harga() {
        return total_harga;
    }
    
}
