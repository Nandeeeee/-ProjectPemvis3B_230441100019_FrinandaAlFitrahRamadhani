/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projekakhir_pemvis;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;


/**
 *
 * @author EBC KOMPUTER
 */
public class DetailTransaksi {
    private int id;
    private int id_transaksi;
    private int id_produk;
    private int jumlah;
    
    public DetailTransaksi(int id, int id_transaksi, int id_produk, int jumlah) {
        this.id = id;
        this.id_transaksi = id_transaksi;
        this.id_produk = id_produk;
        this.jumlah = jumlah;
    }
    
    public static boolean tambah(int id_transaksi, int id_produk, int jumlah){
        String sql = "INSERT INTO detail_transaksi (id_transaksi, id_produk, jumlah) VALUES (?, ?, ?)";
        try (Connection conn = Koneksi.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id_transaksi);
            ps.setInt(2, id_produk);
            ps.setInt(3, jumlah);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
            return true;
        } catch (SQLException e) {
            System.out.println("Error Save Data " + e.getMessage());
        }
        return false;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId_transaksi(int id_transaksi) {
        this.id_transaksi = id_transaksi;
    }

    public int getId_transaksi() {
        return id_transaksi;
    }

    public void setId_produk(int id_produk) {
        this.id_produk = id_produk;
    }

    public int getId_produk() {
        return id_produk;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    public int getJumlah() {
        return jumlah;
    }
    
}
