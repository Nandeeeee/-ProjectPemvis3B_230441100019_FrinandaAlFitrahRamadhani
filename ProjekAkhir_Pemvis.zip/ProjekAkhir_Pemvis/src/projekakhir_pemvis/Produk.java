/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projekakhir_pemvis;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author EBC KOMPUTER
 */
public class Produk {
    private int id;
    private String nama_produk;
    private String deskripsi;
    private double harga;
    private String status;
    private String tipe;
    private String gambar;
    
    public Produk(int id, String nama_produk, String deskripsi, double harga, String status, String tipe, String gambar) {
        this.id = id;
        this.nama_produk = nama_produk;
        this.deskripsi = deskripsi;
        this.harga = harga;
        this.status = status;
        this.tipe = tipe;
        this.gambar = gambar;
    }
    
    public void tambahProduk(){
        String sql = "INSERT INTO produk (nama_produk, deskripsi, harga, status, tipe, gambar) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = Koneksi.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nama_produk);
            ps.setString(2, deskripsi);
            ps.setDouble(3, harga);
            ps.setString(4, status);
            ps.setString(5, tipe);
            ps.setString(6, gambar);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
        } catch (SQLException e) {
            System.out.println("Error Save Data " + e.getMessage());
        }
    }
    
    public void editProduk(){
        String sql = "UPDATE produk SET nama_produk = ?, deskripsi = ?, harga = ?, status = ?, tipe = ?, gambar = ? WHERE id = ?";
        try (Connection conn = Koneksi.getConnection();  
            PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setString(1, this.nama_produk);
            ps.setString(2, this.deskripsi);
            ps.setDouble(3, harga);
            ps.setString(4, status);
            ps.setString(5, tipe);
            ps.setString(6, gambar);
            ps.setInt(7, id);
            ps.executeUpdate();
            System.out.println(id);
            if(ps.executeUpdate() != 0){
                JOptionPane.showMessageDialog(null, "Data Berhasil Diubah");
            }else{
                JOptionPane.showMessageDialog(null, "Data Gagal Diubah");
            }
            
        } catch (SQLException e) {
            System.out.println("Error Save Data " + e.getMessage());
        }
    }

    public void hapusProduk(){
        String sql = "DELETE FROM produk WHERE id = ?";
        try (Connection conn = Koneksi.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setInt(1, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");

        } catch (SQLException e) {
            System.out.println("Error Save Data " + e.getMessage());
        }
    }
    
    public static List<Produk> getdata() {
        List<Produk> p = new ArrayList<>();
        String query = "SELECT * FROM produk";
        
        try (Connection connection = Koneksi.getConnection();
            PreparedStatement ps = connection.prepareStatement(query)) {
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                p.add(new Produk(
                    rs.getInt("id"),
                    rs.getString("nama_produk"),
                    rs.getString("deskripsi"),
                    rs.getInt("harga"),
                    rs.getString("status"),
                    rs.getString("tipe"),
                    rs.getString("gambar")
                ));  
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return p;
    }
    public static Produk getById(int id) {
        Produk p = null;
        String query = "SELECT * FROM produk WHERE id = ?";
        
        try (Connection connection = Koneksi.getConnection();
            PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                p = new Produk(
                    rs.getInt("id"),
                    rs.getString("nama_produk"),
                    rs.getString("deskripsi"),
                    rs.getInt("harga"),
                    rs.getString("status"),
                    rs.getString("tipe"),
                    rs.getString("gambar")
                );  
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return p;
    }
    public static Produk getByNama(String nama_produk) {
        Produk p = null;
        String query = "SELECT * FROM produk WHERE nama_produk = ?";
        
        try (Connection connection = Koneksi.getConnection();
            PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, nama_produk);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                p = new Produk(
                    rs.getInt("id"),
                    rs.getString("nama_produk"),
                    rs.getString("deskripsi"),
                    rs.getInt("harga"),
                    rs.getString("status"),
                    rs.getString("tipe"),
                    rs.getString("gambar")
                );
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return p;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setNama_Produk(String nama_produk) {
        this.nama_produk = nama_produk;
    }

    public String getNama_Produk() {
        return nama_produk;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setHarga(double harga) {
        this.harga = harga;
    }

    public double getHarga() {
        return harga;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setTipe(String tipe) {
        this.tipe = tipe;
    }

    public String getTipe() {
        return tipe;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }

    public String getGambar() {
        return gambar;
    }
    
    
    
}
