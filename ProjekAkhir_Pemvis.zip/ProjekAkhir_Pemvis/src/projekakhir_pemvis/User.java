/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projekakhir_pemvis;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author EBC KOMPUTER
 */
public class User {
    int id;
    String nama;
    String username;
    int password;
    String jenis_kelamin;
    String alamat;
    String no_hp;
    
    User( int id, String nama, String username, int password, String jenis_kelamin, String alamat, String no_hp) {
        this.id = id;
        this.nama = nama;
        this.username = username;
        this.password = password;
        this.jenis_kelamin = jenis_kelamin;
        this.alamat = alamat;
        this.no_hp = no_hp;
    }
    
    public static boolean tambahUser(String nama, String username, int password, String jenis_kelamin, String alamat, String no_hp) {
        String sql = "INSERT INTO user (nama, username, password, jenis_kelamin, alamat, no_hp) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = Koneksi.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nama);
            ps.setString(2, username);
            ps.setInt(3, password);
            ps.setString(4, jenis_kelamin);
            ps.setString(5, alamat);
            ps.setString(6, no_hp);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error Tambah Data di:" + e.getMessage());
            return false;
        }
    }
    
    public static boolean editUser(int id, String nama, String username, int password, String jenis_kelamin, String alamat, String no_hp) {
        String sql = "UPDATE user SET nama = ?, username = ?, password = ?, jenis_kelamin = ?, alamat = ?, no_hp = ?  WHERE id = ?";
        try (Connection conn = Koneksi.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nama);
            ps.setString(2, username);
            ps.setInt(3, password);
            ps.setString(4, jenis_kelamin);
            ps.setString(5, alamat);
            ps.setString(6, no_hp);
            ps.setInt(7, id);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error Tambah Data di:" + e.getMessage());
            return false;
        }
    }
    
    public static User cariUsername(String username) {
        User user = null;
        String query = "SELECT * FROM user WHERE username = ?";
        
        try (Connection connection = Koneksi.getConnection();
            PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                user = new User(
                    rs.getInt("id"),
                    rs.getString("nama"),
                    rs.getString("username"),
                    rs.getInt("password"),
                    rs.getString("jenis_kelamin"),
                    rs.getString("alamat"),
                    rs.getString("no_hp")
                );
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return user;
    }

    public static User loginAdmin (String nama, String password) {
        User user = null;
        String query = "SELECT * FROM admin WHERE nama = ? AND password = ?";
        
        try (Connection connection = Koneksi.getConnection();
            PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, nama);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                user = new User(
                    rs.getInt("id"),
                    rs.getString("nama"),
                    "",
                    rs.getInt("password"),
                    "",
                    "",
                    ""
                );
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return user;
    }
    
    
    public int getId() {
        return id;
    }
    public String getNama() {
        return nama;
    }
    public String getUsername() {
        return username;
    }
    public int getPassword() {
        return password;
    }
    public String getJenis_kelamin() {
        return jenis_kelamin;
    }
    public String getAlamat() {
        return alamat;
    }
    public String getNo_hp() {
        return no_hp;
    }
}
