/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projekakhir_pemvis;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author EBC KOMPUTER
 */
public class Admin extends javax.swing.JFrame {

    Connection conn;
    Produk produkEdit = null;
    VarianProduk varianEdit = null;
    public Admin() {
        initComponents();
        conn = Koneksi.getConnection();
        loadDataUser();
        loadDataProduk();
        loadDataVarian_Produk();
        loadDataTransaksi();
        loadDataDetail_Transaksi();
    }
    
    private void loadDataUser(){
        DefaultTableModel model = (DefaultTableModel) tblPelanggan.getModel();
        model.setRowCount(0);
        
        try {
            String sql = "SELECT * FROM user";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                model.addRow(new Object[]{
                   rs.getInt("id"),
                   rs.getString("nama"),
                   rs.getString("username"),
                   rs.getString("jenis_kelamin"),
                   rs.getString("alamat"),
                   rs.getString("no_hp")
                });
            }
            
        } catch (SQLException e) {
            System.out.println("Error Save Data " + e.getMessage());
        }
    }
    private void loadDataProduk(){
        DefaultTableModel model = (DefaultTableModel) tblProduk.getModel();
        model.setRowCount(0);
        
        try {
            String sql = "SELECT * FROM produk";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                model.addRow(new Object[]{
                   rs.getInt("id"),
                   rs.getString("nama_produk"),
                   rs.getString("deskripsi"),
                   rs.getDouble("harga"),
                   rs.getString("status"),
                   rs.getString("tipe"),
                   rs.getString("gambar")
                });
            }
            
        } catch (SQLException e) {
            System.out.println("Error Save Data " + e.getMessage());
        }
    }
    private void loadDataVarian_Produk(){
        DefaultTableModel model = (DefaultTableModel) tblVarian_Produk.getModel();
        model.setRowCount(0);
        
        try {
            String sql = "SELECT * FROM varian_produk";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                model.addRow(new Object[]{
                   rs.getInt("id"),
                   rs.getInt("id_produk"),
                   rs.getString("atribut_nama"),
                   rs.getString("atribut_nilai"),
                   rs.getInt("stok")
                });
            }
            
        } catch (SQLException e) {
            System.out.println("Error Save Data " + e.getMessage());
        }
    }
    private void loadDataTransaksi(){
        DefaultTableModel model = (DefaultTableModel) tblTransaksi.getModel();
        model.setRowCount(0);
        
        try {
            String sql = "SELECT * FROM transaksi";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                model.addRow(new Object[]{
                   rs.getInt("id"),
                   rs.getInt("id_user"),
                   rs.getDate("tgl_transaksi"),
                   rs.getDouble("total_harga"),
                });
            }
            
        } catch (SQLException e) {
            System.out.println("Error Save Data " + e.getMessage());
        }
    }
    private void loadDataDetail_Transaksi(){
        DefaultTableModel model = (DefaultTableModel) tblDetail_Transaksi.getModel();
        model.setRowCount(0);
        
        try {
            String sql = "SELECT * FROM detail_transaksi";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                model.addRow(new Object[]{
                   rs.getInt("id"),
                   rs.getInt("id_transaksi"),
                   rs.getInt("id_produk"),
                   rs.getInt("jumlah"),
                });
            }
            
        } catch (SQLException e) {
            System.out.println("Error Save Data " + e.getMessage());
        }
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnLogout = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        pelanggan = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        btnCari_Pelanggan = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPelanggan = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        produk = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        btnCari_Produk = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        tambahProduk = new javax.swing.JInternalFrame();
        jPanel12 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        tfNama_ProdukT = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        taDeskripsiT = new javax.swing.JTextArea();
        tfHargaT = new javax.swing.JTextField();
        btnTambah = new javax.swing.JButton();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        cbStatus_ProdukT = new javax.swing.JComboBox<>();
        cbTipe_ProdukT = new javax.swing.JComboBox<>();
        jLabel52 = new javax.swing.JLabel();
        tfGambar_ProdukT = new javax.swing.JTextField();
        editProduk = new javax.swing.JInternalFrame();
        jPanel21 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        tfNama_ProdukE = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        taDeskripsiE = new javax.swing.JTextArea();
        tfHargaE = new javax.swing.JTextField();
        btnEdit = new javax.swing.JButton();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        cbStatus_ProdukE = new javax.swing.JComboBox<>();
        cbTipe_ProdukE = new javax.swing.JComboBox<>();
        jLabel53 = new javax.swing.JLabel();
        tfGambar_ProdukE = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblProduk = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnTambah_Produk = new javax.swing.JButton();
        btnHapus_Produk = new javax.swing.JButton();
        btnEdit_Produk = new javax.swing.JButton();
        varian_produk = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        btnCari_Varian = new javax.swing.JButton();
        jPanel14 = new javax.swing.JPanel();
        tambahVarian = new javax.swing.JInternalFrame();
        jPanel20 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        tfA_NamaT = new javax.swing.JTextField();
        btnTambahV = new javax.swing.JButton();
        jLabel42 = new javax.swing.JLabel();
        tfA_NilaiT = new javax.swing.JTextField();
        tfStokT = new javax.swing.JTextField();
        cbId_ProdukT = new javax.swing.JComboBox<>();
        editVarian = new javax.swing.JInternalFrame();
        jPanel22 = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        tfA_NamaE = new javax.swing.JTextField();
        btnEditV = new javax.swing.JButton();
        jLabel51 = new javax.swing.JLabel();
        tfA_NilaiE = new javax.swing.JTextField();
        tfStokE = new javax.swing.JTextField();
        cbId_ProdukE = new javax.swing.JComboBox<>();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblVarian_Produk = new javax.swing.JTable();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        btnTambah_Varian = new javax.swing.JButton();
        btnHapus_Varian = new javax.swing.JButton();
        btnEdit_Varian = new javax.swing.JButton();
        transaksi = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        btnCari_Transaksi = new javax.swing.JButton();
        jPanel16 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblTransaksi = new javax.swing.JTable();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        btnCari_Detail = new javax.swing.JButton();
        jPanel18 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        tblDetail_Transaksi = new javax.swing.JTable();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setText("__________________________________________________________________________________________________________________________________________________________");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 72, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setText("DataBase");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(203, 18, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(15, 175, 25));
        jLabel4.setText("TradisiWare");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(365, 18, -1, -1));

        btnLogout.setBackground(new java.awt.Color(15, 175, 25));
        btnLogout.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLogout.setForeground(new java.awt.Color(255, 255, 255));
        btnLogout.setText("Logout");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });
        jPanel2.add(btnLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 50, -1, -1));

        jPanel1.add(jPanel2, java.awt.BorderLayout.PAGE_START);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jTabbedPane1.setBackground(new java.awt.Color(15, 175, 25));
        jTabbedPane1.setForeground(new java.awt.Color(255, 255, 255));

        pelanggan.setBackground(new java.awt.Color(255, 255, 255));
        pelanggan.setLayout(new java.awt.BorderLayout());

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnCari_Pelanggan.setBackground(new java.awt.Color(15, 175, 25));
        btnCari_Pelanggan.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCari_Pelanggan.setForeground(new java.awt.Color(255, 255, 255));
        btnCari_Pelanggan.setText("Cari");
        btnCari_Pelanggan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCari_PelangganActionPerformed(evt);
            }
        });
        jPanel4.add(btnCari_Pelanggan);

        pelanggan.add(jPanel4, java.awt.BorderLayout.PAGE_START);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        tblPelanggan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID Pelanggan", "Nama", "Username", "Jenis Kelamin", "Alamat", "No.Hp"
            }
        ));
        jScrollPane1.setViewportView(tblPelanggan);
        if (tblPelanggan.getColumnModel().getColumnCount() > 0) {
            tblPelanggan.getColumnModel().getColumn(4).setHeaderValue("Stok");
        }

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setText("Tabel Data");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(15, 175, 25));
        jLabel1.setText("Pelanggan");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addContainerGap(259, Short.MAX_VALUE))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );

        pelanggan.add(jPanel5, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("Pelanggan", pelanggan);

        produk.setBackground(new java.awt.Color(255, 255, 255));
        produk.setLayout(new java.awt.BorderLayout());

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnCari_Produk.setBackground(new java.awt.Color(15, 175, 25));
        btnCari_Produk.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCari_Produk.setForeground(new java.awt.Color(255, 255, 255));
        btnCari_Produk.setText("Cari");
        jPanel6.add(btnCari_Produk);

        produk.add(jPanel6, java.awt.BorderLayout.PAGE_START);

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tambahProduk.setClosable(true);
        tambahProduk.setVisible(false);

        jPanel12.setBackground(new java.awt.Color(15, 175, 25));

        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("Tambah Produk");

        jLabel31.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("Nama Produk");

        jLabel32.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("Deskripsi");

        jLabel34.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("Harga");

        taDeskripsiT.setColumns(20);
        taDeskripsiT.setRows(5);
        jScrollPane4.setViewportView(taDeskripsiT);

        btnTambah.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnTambah.setText("Tambah");
        btnTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahActionPerformed(evt);
            }
        });

        jLabel38.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("Status");

        jLabel39.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("Tipe");

        cbStatus_ProdukT.setForeground(new java.awt.Color(51, 51, 51));
        cbStatus_ProdukT.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Status --", "Tersedia", "Tidak Tersedia" }));

        cbTipe_ProdukT.setForeground(new java.awt.Color(51, 51, 51));
        cbTipe_ProdukT.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Tipe --", "Pakaian", "Kerajinan Tangan", "Alat Musik" }));

        jLabel52.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel52.setForeground(new java.awt.Color(255, 255, 255));
        jLabel52.setText("Gambar *(namafile.jpg)");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(114, 114, 114)
                .addComponent(jLabel30)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel34)
                            .addComponent(jLabel32)
                            .addComponent(jLabel31))
                        .addContainerGap(264, Short.MAX_VALUE))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel52)
                            .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(tfHargaT, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                                .addComponent(jLabel39, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel38, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tfNama_ProdukT, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btnTambah, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cbStatus_ProdukT, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cbTipe_ProdukT, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(tfGambar_ProdukT, javax.swing.GroupLayout.Alignment.LEADING)))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel30)
                .addGap(16, 16, 16)
                .addComponent(jLabel31)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfNama_ProdukT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel32)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel34)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfHargaT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel38)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbStatus_ProdukT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel39)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbTipe_ProdukT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel52)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfGambar_ProdukT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnTambah)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout tambahProdukLayout = new javax.swing.GroupLayout(tambahProduk.getContentPane());
        tambahProduk.getContentPane().setLayout(tambahProdukLayout);
        tambahProdukLayout.setHorizontalGroup(
            tambahProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        tambahProdukLayout.setVerticalGroup(
            tambahProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel7.add(tambahProduk, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 400, 490));

        editProduk.setClosable(true);
        editProduk.setVisible(false);

        jPanel21.setBackground(new java.awt.Color(15, 175, 25));

        jLabel37.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("Edit Produk");

        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("Nama Produk");

        jLabel43.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("Deskripsi");

        jLabel44.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(255, 255, 255));
        jLabel44.setText("Harga");

        taDeskripsiE.setColumns(20);
        taDeskripsiE.setRows(5);
        jScrollPane5.setViewportView(taDeskripsiE);

        btnEdit.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEdit.setText("Edit");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        jLabel45.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(255, 255, 255));
        jLabel45.setText("Status");

        jLabel46.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 255, 255));
        jLabel46.setText("Tipe");

        cbStatus_ProdukE.setForeground(new java.awt.Color(51, 51, 51));
        cbStatus_ProdukE.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Status --", "tersedia", "tidak tersedia" }));

        cbTipe_ProdukE.setForeground(new java.awt.Color(51, 51, 51));
        cbTipe_ProdukE.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Item --", "Pakaian", "Kerajinan Tangan", "Alat Musik" }));

        jLabel53.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel53.setForeground(new java.awt.Color(255, 255, 255));
        jLabel53.setText("Gambar *(namafile.jpg)");

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel21Layout.createSequentialGroup()
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel44)
                            .addComponent(jLabel43)
                            .addComponent(jLabel40))
                        .addContainerGap(264, Short.MAX_VALUE))
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel53)
                            .addComponent(tfHargaE)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                            .addComponent(jLabel46)
                            .addComponent(jLabel45)
                            .addComponent(tfNama_ProdukE)
                            .addComponent(btnEdit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbStatus_ProdukE, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbTipe_ProdukE, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tfGambar_ProdukE))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addGap(124, 124, 124)
                .addComponent(jLabel37)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel37)
                .addGap(16, 16, 16)
                .addComponent(jLabel40)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfNama_ProdukE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel43)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel44)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfHargaE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel45)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbStatus_ProdukE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel46)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbTipe_ProdukE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel53)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfGambar_ProdukE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnEdit)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout editProdukLayout = new javax.swing.GroupLayout(editProduk.getContentPane());
        editProduk.getContentPane().setLayout(editProdukLayout);
        editProdukLayout.setHorizontalGroup(
            editProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel21, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        editProdukLayout.setVerticalGroup(
            editProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel7.add(editProduk, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 0, 400, 490));

        tblProduk.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID Produk", "Nama Produk", "Deskripsi", "Harga", "Status", "Tipe"
            }
        ));
        tblProduk.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblProdukMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblProduk);

        jPanel7.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 59, 758, 331));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setText("Tabel Data");
        jPanel7.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(15, 175, 25));
        jLabel6.setText("Produk");
        jPanel7.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(402, 9, -1, -1));

        btnTambah_Produk.setBackground(new java.awt.Color(15, 175, 25));
        btnTambah_Produk.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnTambah_Produk.setForeground(new java.awt.Color(255, 255, 255));
        btnTambah_Produk.setText("Tambah");
        btnTambah_Produk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambah_ProdukActionPerformed(evt);
            }
        });
        jPanel7.add(btnTambah_Produk, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 440, -1, -1));

        btnHapus_Produk.setBackground(new java.awt.Color(15, 175, 25));
        btnHapus_Produk.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnHapus_Produk.setForeground(new java.awt.Color(255, 255, 255));
        btnHapus_Produk.setText("Hapus");
        btnHapus_Produk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapus_ProdukActionPerformed(evt);
            }
        });
        jPanel7.add(btnHapus_Produk, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 440, -1, -1));

        btnEdit_Produk.setBackground(new java.awt.Color(15, 175, 25));
        btnEdit_Produk.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEdit_Produk.setForeground(new java.awt.Color(255, 255, 255));
        btnEdit_Produk.setText("Edit");
        btnEdit_Produk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEdit_ProdukActionPerformed(evt);
            }
        });
        jPanel7.add(btnEdit_Produk, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 440, -1, -1));

        produk.add(jPanel7, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("Produk", produk);

        varian_produk.setBackground(new java.awt.Color(255, 255, 255));
        varian_produk.setLayout(new java.awt.BorderLayout());

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));
        jPanel13.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnCari_Varian.setBackground(new java.awt.Color(15, 175, 25));
        btnCari_Varian.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCari_Varian.setForeground(new java.awt.Color(255, 255, 255));
        btnCari_Varian.setText("Cari");
        jPanel13.add(btnCari_Varian);

        varian_produk.add(jPanel13, java.awt.BorderLayout.PAGE_START);

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));
        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tambahVarian.setClosable(true);
        tambahVarian.setVisible(false);

        jPanel20.setBackground(new java.awt.Color(15, 175, 25));

        jLabel33.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("Tambah Varian Produk");

        jLabel35.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("ID Produk");

        jLabel36.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("Atribut Nama");

        jLabel41.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("Atribut Nilai");

        btnTambahV.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnTambahV.setText("Tambah");
        btnTambahV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahVActionPerformed(evt);
            }
        });

        jLabel42.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("Stok");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel33)
                .addGap(56, 56, 56))
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                        .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel42)
                            .addComponent(jLabel41)
                            .addComponent(jLabel36)
                            .addComponent(jLabel35))
                        .addContainerGap(264, Short.MAX_VALUE))
                    .addGroup(jPanel20Layout.createSequentialGroup()
                        .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btnTambahV, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                            .addComponent(tfA_NamaT, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfA_NilaiT, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfStokT, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbId_ProdukT, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel33)
                .addGap(16, 16, 16)
                .addComponent(jLabel35)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbId_ProdukT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel36)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfA_NamaT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel41)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfA_NilaiT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel42)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfStokT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnTambahV)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout tambahVarianLayout = new javax.swing.GroupLayout(tambahVarian.getContentPane());
        tambahVarian.getContentPane().setLayout(tambahVarianLayout);
        tambahVarianLayout.setHorizontalGroup(
            tambahVarianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel20, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        tambahVarianLayout.setVerticalGroup(
            tambahVarianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel14.add(tambahVarian, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 400, 360));

        editVarian.setClosable(true);
        editVarian.setVisible(false);

        jPanel22.setBackground(new java.awt.Color(15, 175, 25));

        jLabel47.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 255, 255));
        jLabel47.setText("Edit Varian Produk");

        jLabel48.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(255, 255, 255));
        jLabel48.setText("ID Produk");

        jLabel49.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(255, 255, 255));
        jLabel49.setText("Atribut Nama");

        jLabel50.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel50.setForeground(new java.awt.Color(255, 255, 255));
        jLabel50.setText("Atribut Nilai");

        btnEditV.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEditV.setText("Edit");
        btnEditV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditVActionPerformed(evt);
            }
        });

        jLabel51.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(255, 255, 255));
        jLabel51.setText("Stok");

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel51)
                            .addComponent(jLabel50)
                            .addComponent(jLabel49)
                            .addComponent(jLabel48))
                        .addContainerGap(264, Short.MAX_VALUE))
                    .addGroup(jPanel22Layout.createSequentialGroup()
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btnEditV, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                            .addComponent(tfA_NamaE, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfA_NilaiE, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfStokE, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbId_ProdukE, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel47)
                .addGap(83, 83, 83))
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel47)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel48)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbId_ProdukE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel49)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfA_NamaE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel50)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfA_NilaiE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel51)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfStokE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnEditV)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout editVarianLayout = new javax.swing.GroupLayout(editVarian.getContentPane());
        editVarian.getContentPane().setLayout(editVarianLayout);
        editVarianLayout.setHorizontalGroup(
            editVarianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel22, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        editVarianLayout.setVerticalGroup(
            editVarianLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel14.add(editVarian, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 400, 360));

        tblVarian_Produk.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID Varian", "ID Produk", "Atribut Nama", "Atribur Nilai", "Stok"
            }
        ));
        tblVarian_Produk.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblVarian_ProdukMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(tblVarian_Produk);
        if (tblVarian_Produk.getColumnModel().getColumnCount() > 0) {
            tblVarian_Produk.getColumnModel().getColumn(4).setHeaderValue("Stok");
        }

        jPanel14.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 59, 758, 331));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel14.setText("Tabel Data");
        jPanel14.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 10, -1, -1));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(15, 175, 25));
        jLabel15.setText("Varian Produk");
        jPanel14.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(382, 9, -1, -1));

        btnTambah_Varian.setBackground(new java.awt.Color(15, 175, 25));
        btnTambah_Varian.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnTambah_Varian.setForeground(new java.awt.Color(255, 255, 255));
        btnTambah_Varian.setText("Tambah");
        btnTambah_Varian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambah_VarianActionPerformed(evt);
            }
        });
        jPanel14.add(btnTambah_Varian, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 440, -1, -1));

        btnHapus_Varian.setBackground(new java.awt.Color(15, 175, 25));
        btnHapus_Varian.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnHapus_Varian.setForeground(new java.awt.Color(255, 255, 255));
        btnHapus_Varian.setText("Hapus");
        btnHapus_Varian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapus_VarianActionPerformed(evt);
            }
        });
        jPanel14.add(btnHapus_Varian, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 440, -1, -1));

        btnEdit_Varian.setBackground(new java.awt.Color(15, 175, 25));
        btnEdit_Varian.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEdit_Varian.setForeground(new java.awt.Color(255, 255, 255));
        btnEdit_Varian.setText("Edit");
        btnEdit_Varian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEdit_VarianActionPerformed(evt);
            }
        });
        jPanel14.add(btnEdit_Varian, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 440, -1, -1));

        varian_produk.add(jPanel14, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("Varian Produk", varian_produk);

        transaksi.setBackground(new java.awt.Color(255, 255, 255));
        transaksi.setLayout(new java.awt.BorderLayout());

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));
        jPanel15.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnCari_Transaksi.setBackground(new java.awt.Color(15, 175, 25));
        btnCari_Transaksi.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCari_Transaksi.setForeground(new java.awt.Color(255, 255, 255));
        btnCari_Transaksi.setText("Cari");
        jPanel15.add(btnCari_Transaksi);

        transaksi.add(jPanel15, java.awt.BorderLayout.PAGE_START);

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));

        tblTransaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID Transaksi", "ID Pelanggan", "Tanggal Transaksi", "Total Harga"
            }
        ));
        jScrollPane7.setViewportView(tblTransaksi);

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel16.setText("Tabel Data");

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(15, 175, 25));
        jLabel17.setText("Transaksi");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 758, Short.MAX_VALUE))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGap(254, 254, 254)
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel17)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(jLabel17))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );

        transaksi.add(jPanel16, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("Transaksi", transaksi);

        jPanel19.setBackground(new java.awt.Color(255, 255, 255));
        jPanel19.setLayout(new java.awt.BorderLayout());

        jPanel17.setBackground(new java.awt.Color(255, 255, 255));
        jPanel17.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnCari_Detail.setBackground(new java.awt.Color(15, 175, 25));
        btnCari_Detail.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnCari_Detail.setForeground(new java.awt.Color(255, 255, 255));
        btnCari_Detail.setText("Cari");
        btnCari_Detail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCari_DetailActionPerformed(evt);
            }
        });
        jPanel17.add(btnCari_Detail);

        jPanel19.add(jPanel17, java.awt.BorderLayout.PAGE_START);

        jPanel18.setBackground(new java.awt.Color(255, 255, 255));

        tblDetail_Transaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID Detail", "ID Transaksi", "ID Produk", "Jumlah", "Harga Satuan", "SubTotal"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, true, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane8.setViewportView(tblDetail_Transaksi);

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel18.setText("Tabel Data");

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(15, 175, 25));
        jLabel19.setText("Detail Transaksi");

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane8))
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addGap(254, 254, 254)
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel19)
                        .addGap(0, 201, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(jLabel19))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel19.add(jPanel18, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("Detail Transaksi", jPanel19);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 562, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, java.awt.BorderLayout.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCari_DetailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCari_DetailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCari_DetailActionPerformed

    private void btnTambah_ProdukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambah_ProdukActionPerformed
        tambahProduk.setVisible(true);
    }//GEN-LAST:event_btnTambah_ProdukActionPerformed

    private void btnEdit_ProdukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEdit_ProdukActionPerformed
        if (varianEdit == null) {
            JOptionPane.showMessageDialog(null, "Pilih Varian Produk Terlebih Dahulu", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
        } else {
            editProduk.setVisible(true);
            tfNama_ProdukE.setText(produkEdit.getNama_Produk());
            taDeskripsiE.setText(produkEdit.getDeskripsi());
            tfHargaE.setText(Double.toString(produkEdit.getHarga()));
            cbStatus_ProdukE.setSelectedItem(produkEdit.getStatus());
            cbTipe_ProdukE.setSelectedItem(produkEdit.getTipe());        
            tfGambar_ProdukE.setText(produkEdit.getGambar());
        }
    }//GEN-LAST:event_btnEdit_ProdukActionPerformed

    private void btnTambah_VarianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambah_VarianActionPerformed
        tambahVarian.setVisible(true);
        List<Produk> p = Produk.getdata();
        for (Produk pp : p) {
            cbId_ProdukT.addItem(Integer.toString(pp.getId()));
        }
    }//GEN-LAST:event_btnTambah_VarianActionPerformed

    private void btnEdit_VarianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEdit_VarianActionPerformed
        if (varianEdit == null) {
            JOptionPane.showMessageDialog(null, "Pilih Varian Produk Terlebih Dahulu", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
        } else {
            editVarian.setVisible(true);
            
            List<Produk> p = Produk.getdata();
            for (Produk pp : p) {
                cbId_ProdukE.addItem(Integer.toString(pp.getId()));
                cbId_ProdukE.setSelectedItem(Integer.toString(varianEdit.getId_produk()));
            }
            
            tfA_NamaE.setText(varianEdit.getAtribut_nama());
            tfA_NilaiE.setText(varianEdit.getAtribut_nilai());
            tfStokE.setText(Integer.toString(varianEdit.getStok()));
        }
        
    }//GEN-LAST:event_btnEdit_VarianActionPerformed

    private void btnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahActionPerformed
        String nama_produk = tfNama_ProdukT.getText();
        String deskripsi = taDeskripsiT.getText();
        String harga = tfHargaT.getText();
        String status = cbStatus_ProdukT.getSelectedItem().toString();
        String tipe = cbTipe_ProdukT.getSelectedItem().toString();
        String gambar = tfGambar_ProdukT.getText();
        try {
            if(nama_produk.isEmpty() || deskripsi.isEmpty() || harga.isEmpty() || cbStatus_ProdukT.getSelectedIndex() == 0 || cbTipe_ProdukT.getSelectedIndex() == 0 || gambar.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Data Tidak Boleh Kosong" , "Peringatan", JOptionPane.ERROR_MESSAGE);
            } else {
                double harga2 = Double.parseDouble(harga);
                Produk pdk = new Produk(0, nama_produk, deskripsi, harga2, status, tipe, gambar);
                pdk.tambahProduk();
                tambahProduk.setVisible(false);
                loadDataProduk();

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Masukkan Data Dengan Benar!", "Peringatan", JOptionPane.ERROR_MESSAGE);
        }
        
    }//GEN-LAST:event_btnTambahActionPerformed

    private void tblProdukMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblProdukMouseClicked
        int row = tblProduk.rowAtPoint(evt.getPoint());
        int id = (int) tblProduk.getValueAt(row, 0);
        produkEdit = Produk.getById(id);
    }//GEN-LAST:event_tblProdukMouseClicked

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
        String nama_produk = tfNama_ProdukE.getText();
        String deskripsi = taDeskripsiE.getText();
        String harga = tfHargaE.getText();
        String status = cbStatus_ProdukE.getSelectedItem().toString();
        String tipe = cbTipe_ProdukE.getSelectedItem().toString();
        String gambar = tfGambar_ProdukE.getText();
        try {
            if(nama_produk.isEmpty() || deskripsi.isEmpty() || harga.isEmpty() || cbStatus_ProdukE.getSelectedIndex() == 0 || cbTipe_ProdukE.getSelectedIndex() == 0 || gambar.isEmpty()){
                JOptionPane.showMessageDialog(null, "Data Tidak Boleh Kosong", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
            } else {
                double harga2 = Double.parseDouble(harga);
                Produk pdk = new Produk(produkEdit.getId(), nama_produk, deskripsi, harga2, status, tipe, gambar);
                pdk.editProduk();
                editProduk.setVisible(false);
                loadDataProduk();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Masukkan Data Dengan Benar!", "Peringatan", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnTambahVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahVActionPerformed
        String id_produk = cbId_ProdukT.getSelectedItem().toString();
        String atribut_nama = tfA_NamaT.getText();
        String atribut_nilai = tfA_NilaiT.getText();
        String stok = tfStokT.getText();
        
        try {
            if(id_produk.isEmpty() || atribut_nama.isEmpty() || atribut_nilai.isEmpty() || stok.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Data Tidak Boleh Kosong" , "Peringatan", JOptionPane.ERROR_MESSAGE);
            } else {
                int id_produk2 = Integer.parseInt(id_produk);
                int stok2 = Integer.parseInt(stok);
                VarianProduk vp = new VarianProduk(0, id_produk2, atribut_nama, atribut_nilai, stok2);
                vp.tambahVarian_Produk();
                tambahVarian.setVisible(false);
                loadDataVarian_Produk();

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Masukkan Data Dengan Benar!" + e, "Peringatan", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnTambahVActionPerformed

    private void tblVarian_ProdukMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblVarian_ProdukMouseClicked
        int row = tblVarian_Produk.rowAtPoint(evt.getPoint());
        int id = (int) tblVarian_Produk.getValueAt(row, 0);
        varianEdit = VarianProduk.getVaProById(id);
    }//GEN-LAST:event_tblVarian_ProdukMouseClicked

    private void btnEditVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditVActionPerformed
        String id_produk = cbId_ProdukE.getSelectedItem().toString();
        String atribut_nama = tfA_NamaE.getText();
        String atribut_nilai = tfA_NilaiE.getText();
        String stok = tfStokE.getText();
        
        try {
            if(atribut_nama.isEmpty() || atribut_nilai.isEmpty() || stok.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Data Tidak Boleh Kosong" , "Peringatan", JOptionPane.ERROR_MESSAGE);
            } else {
                int id_produk2 = Integer.parseInt(id_produk);
                int stok2 = Integer.parseInt(stok);
                VarianProduk vp = new VarianProduk(varianEdit.getId(), id_produk2, atribut_nama, atribut_nilai, stok2);
                vp.editVarian_Produk();
                editVarian.setVisible(false);
                loadDataVarian_Produk();

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Masukkan Data Dengan Benar!" + e, "Peringatan", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnEditVActionPerformed

    private void btnHapus_VarianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapus_VarianActionPerformed
        if (varianEdit == null) {
            JOptionPane.showMessageDialog(null, "Pilih Varian Produk Terlebih Dahulu", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
        } else {
            int pilihan = JOptionPane.showConfirmDialog(null, "Apakah Anda Yakin Ingin \nMenghapus Data Dengan ID Varian = " + varianEdit.getId() + " ? ", "Perhatian", JOptionPane.OK_CANCEL_OPTION);
            if(pilihan == JOptionPane.OK_OPTION){
                VarianProduk vp = new VarianProduk(varianEdit.getId(), varianEdit.getId_produk(), varianEdit.getAtribut_nama(), varianEdit.getAtribut_nilai(), varianEdit.getStok());
                vp.hapusVarian_Produk();
                loadDataVarian_Produk();
            }
        }
    }//GEN-LAST:event_btnHapus_VarianActionPerformed

    private void btnHapus_ProdukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapus_ProdukActionPerformed
        if (produkEdit == null) {
            JOptionPane.showMessageDialog(null, "Pilih Produk Terlebih Dahulu", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
        } else {
            int pilihan = JOptionPane.showConfirmDialog(null, "Apakah Anda Yakin Ingin \nMenghapus Data Dengan ID Produk = " + produkEdit.getId() + " ? ", "Perhatian", JOptionPane.OK_CANCEL_OPTION);
            if(pilihan == JOptionPane.OK_OPTION){
                Produk pdk = new Produk(produkEdit.getId(), produkEdit.getNama_Produk(), produkEdit.getDeskripsi(), produkEdit.getHarga(), produkEdit.getStatus(), produkEdit.getTipe(), produkEdit.getGambar());
                pdk.hapusProduk();
                loadDataProduk();
            }
        }
    }//GEN-LAST:event_btnHapus_ProdukActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        int pilihan = JOptionPane.showConfirmDialog(null, "Yakin Ingin Logout?", "Perhatian", JOptionPane.OK_CANCEL_OPTION);
        if(pilihan == JOptionPane.OK_OPTION){
            new TradisiWare().setVisible(true);
            this.dispose();
        }

    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnCari_PelangganActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCari_PelangganActionPerformed
        
    }//GEN-LAST:event_btnCari_PelangganActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCari_Detail;
    private javax.swing.JButton btnCari_Pelanggan;
    private javax.swing.JButton btnCari_Produk;
    private javax.swing.JButton btnCari_Transaksi;
    private javax.swing.JButton btnCari_Varian;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnEditV;
    private javax.swing.JButton btnEdit_Produk;
    private javax.swing.JButton btnEdit_Varian;
    private javax.swing.JButton btnHapus_Produk;
    private javax.swing.JButton btnHapus_Varian;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnTambah;
    private javax.swing.JButton btnTambahV;
    private javax.swing.JButton btnTambah_Produk;
    private javax.swing.JButton btnTambah_Varian;
    private javax.swing.JComboBox<String> cbId_ProdukE;
    private javax.swing.JComboBox<String> cbId_ProdukT;
    private javax.swing.JComboBox<String> cbStatus_ProdukE;
    private javax.swing.JComboBox<String> cbStatus_ProdukT;
    private javax.swing.JComboBox<String> cbTipe_ProdukE;
    private javax.swing.JComboBox<String> cbTipe_ProdukT;
    private javax.swing.JInternalFrame editProduk;
    private javax.swing.JInternalFrame editVarian;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel pelanggan;
    private javax.swing.JPanel produk;
    private javax.swing.JTextArea taDeskripsiE;
    private javax.swing.JTextArea taDeskripsiT;
    private javax.swing.JInternalFrame tambahProduk;
    private javax.swing.JInternalFrame tambahVarian;
    private javax.swing.JTable tblDetail_Transaksi;
    private javax.swing.JTable tblPelanggan;
    private javax.swing.JTable tblProduk;
    private javax.swing.JTable tblTransaksi;
    private javax.swing.JTable tblVarian_Produk;
    private javax.swing.JTextField tfA_NamaE;
    private javax.swing.JTextField tfA_NamaT;
    private javax.swing.JTextField tfA_NilaiE;
    private javax.swing.JTextField tfA_NilaiT;
    private javax.swing.JTextField tfGambar_ProdukE;
    private javax.swing.JTextField tfGambar_ProdukT;
    private javax.swing.JTextField tfHargaE;
    private javax.swing.JTextField tfHargaT;
    private javax.swing.JTextField tfNama_ProdukE;
    private javax.swing.JTextField tfNama_ProdukT;
    private javax.swing.JTextField tfStokE;
    private javax.swing.JTextField tfStokT;
    private javax.swing.JPanel transaksi;
    private javax.swing.JPanel varian_produk;
    // End of variables declaration//GEN-END:variables
}
