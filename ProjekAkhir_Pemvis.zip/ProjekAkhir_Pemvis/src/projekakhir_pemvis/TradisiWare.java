/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projekakhir_pemvis;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author EBC KOMPUTER
 */
public class TradisiWare extends javax.swing.JFrame {
    User userLogin = null;
    Produk produkDetail = null;
    Connection conn;
    public TradisiWare() {
        initComponents();
        conn = Koneksi.getConnection();
        loadDataDaftar_Produk("");
        loadDataRiwayat_Pembelian();
        loadDataUser();
        LHalo.setText("");
        LWellcome.setText("");
        page();
    }
    
    private void page() {
        if (userLogin == null) {
            jTabbedPane1.setEnabledAt(1, false);
            jTabbedPane1.setEnabledAt(2, false);
            jTabbedPane1.setEnabledAt(3, false);
        } else {
            jTabbedPane1.setEnabledAt(1, true);
            jTabbedPane1.setEnabledAt(2, true);
            jTabbedPane1.setEnabledAt(3, true);
        }
    }
    private void reset(){
        tfUser_Login.setText("");
        tfPw_Login.setText("");
        
        tfNama_Register.setText("");
        tfUser_Register.setText("");
        tfPw_Register.setText("");
        JK_Register.clearSelection();
        taAlamat_Register.setText("");
        tfHp_Register.setText("");
        
        cbNilaiVarian.removeAllItems();
        tfJumlah_Beli.setText("");
    }
    private void loadDataDaftar_Produk(String tipe){
        DefaultTableModel model = (DefaultTableModel) tblDaftar_Produk.getModel();
        model.setRowCount(0);
        
        if (tipe.isEmpty() || tipe.equalsIgnoreCase("semua")) {
            try {
                String sql = "SELECT * FROM produk";
                PreparedStatement ps = conn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                while(rs.next()){
                    model.addRow(new Object[]{
                       rs.getString("nama_produk"),
                       rs.getDouble("harga"),
                       rs.getString("status")
                    });
                }

            } catch (SQLException e) {
                System.out.println("Error Save Data " + e.getMessage());
            } 
        } else {
            try {
                String sql = "SELECT * FROM produk WHERE tipe = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, tipe);
                ResultSet rs = ps.executeQuery();
                while(rs.next()){
                    model.addRow(new Object[]{
                       rs.getString("nama_produk"),
                       rs.getDouble("harga"),
                       rs.getString("status")
                    });
                }

            } catch (SQLException e) {
                System.out.println("Error Save Data " + e.getMessage());
            } 
        }
    }
    private void loadDataRiwayat_Pembelian(){
        if (userLogin != null) {
            DefaultTableModel model = (DefaultTableModel) tblRiwayat.getModel();
            model.setRowCount(0);

            try {
                String sql = 
                    "SELECT * FROM detail_transaksi " +
                    "INNER JOIN transaksi ON detail_transaksi.id_transaksi = transaksi.id " +
                    "INNER JOIN varian_produk ON varian_produk.id = detail_transaksi.id_varian_produk " +
                    "INNER JOIN produk ON produk.id = varian_produk.id_produk " +
                    "WHERE id_user = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, userLogin.getId());
                ResultSet rs = ps.executeQuery();
                while(rs.next()){
                    model.addRow(new Object[]{
                        rs.getInt("detail_transaksi.id"),
                        rs.getString("produk.nama_produk"),
                        rs.getInt("produk.harga"),
                        rs.getInt("detail_transaksi.jumlah"),
                        rs.getString("varian_produk.atribut_nama") + " " + rs.getString("varian_produk.atribut_nilai"),
                        rs.getInt("transaksi.total_harga")
                    });
                    System.out.println(rs.getInt("jumlah"));
                }

            } catch (SQLException e) {
                System.out.println("Error Save Data " + e.getMessage());
            } 
        }
    }   
    private void loadDataUser() {
        if (userLogin != null) {
            tfNama_Profil.setText(userLogin.getNama());
            tfUser_Profil.setText(userLogin.getUsername());
            tfPw_Profil.setText(Integer.toString(userLogin.getPassword()));
            tfJK_Profil.setText(userLogin.getJenis_kelamin());
            taAlamat_Profil.setText(userLogin.getAlamat());
            tfHp_Profil.setText(userLogin.getNo_hp());

            tfNama_Edit.setText(userLogin.getNama());
            tfUser_Edit.setText(userLogin.getUsername());
            tfPw_Edit.setText(Integer.toString(userLogin.getPassword()));
            if (userLogin.getJenis_kelamin().equalsIgnoreCase("Laki-Laki")) {
                rbLk_Edit.setSelected(true);
            } else {
                rbPr_Edit.setSelected(true);
            }
            taAlamat_Edit.setText(userLogin.getAlamat());
            tfHp_Edit.setText(userLogin.getNo_hp());
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        JenisKelamin = new javax.swing.ButtonGroup();
        JK_Register = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        beranda = new javax.swing.JPanel();
        formLogin = new javax.swing.JInternalFrame();
        jPanel10 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        tfUser_Login = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        btnMasuk = new javax.swing.JButton();
        tfPw_Login = new javax.swing.JPasswordField();
        formRegister = new javax.swing.JInternalFrame();
        jPanel11 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        tfNama_Register = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        tfPw_Register = new javax.swing.JPasswordField();
        tfUser_Register = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        rbLk_Register = new javax.swing.JRadioButton();
        rbPr_Register = new javax.swing.JRadioButton();
        jLabel28 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        taAlamat_Register = new javax.swing.JTextArea();
        jLabel29 = new javax.swing.JLabel();
        tfHp_Register = new javax.swing.JTextField();
        btnDaftar = new javax.swing.JButton();
        LHalo = new javax.swing.JLabel();
        LWellcome = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        btnLihat_Produk = new javax.swing.JButton();
        btnLogin = new javax.swing.JButton();
        btnRegister = new javax.swing.JButton();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        produk = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        cbJenis_Produk = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        detailProduk = new javax.swing.JInternalFrame();
        jPanel13 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        LNama_Produk = new javax.swing.JLabel();
        LGambar_Produk = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        taDetail_Produk = new javax.swing.JTextArea();
        beliProduk = new javax.swing.JInternalFrame();
        jPanel20 = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        tfNama_Beli = new javax.swing.JTextField();
        btnBeli = new javax.swing.JButton();
        namaVarian = new javax.swing.JLabel();
        tfHarga_Beli = new javax.swing.JTextField();
        tfJumlah_Beli = new javax.swing.JTextField();
        jLabel47 = new javax.swing.JLabel();
        cbNilaiVarian = new javax.swing.JComboBox<>();
        jScrollPane9 = new javax.swing.JScrollPane();
        tblDaftar_Produk = new javax.swing.JTable();
        jLabel19 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        btnDetail_Produk = new javax.swing.JButton();
        btnBeli_Produk = new javax.swing.JButton();
        riwayat = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        tblRiwayat = new javax.swing.JTable();
        profil = new javax.swing.JPanel();
        editProfil = new javax.swing.JInternalFrame();
        jPanel12 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        tfNama_Edit = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        tfPw_Edit = new javax.swing.JPasswordField();
        tfUser_Edit = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        rbLk_Edit = new javax.swing.JRadioButton();
        rbPr_Edit = new javax.swing.JRadioButton();
        jLabel35 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        taAlamat_Edit = new javax.swing.JTextArea();
        jLabel36 = new javax.swing.JLabel();
        tfHp_Edit = new javax.swing.JTextField();
        btnEdit = new javax.swing.JButton();
        LGambar_Profil = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        tfNama_Profil = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        tfUser_Profil = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        tfJK_Profil = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        tfHp_Profil = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        taAlamat_Profil = new javax.swing.JTextArea();
        btnEdit_Profil = new javax.swing.JButton();
        tfPw_Profil = new javax.swing.JPasswordField();
        btnLogout = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(15, 175, 25));
        jLabel1.setText("TradisiWare");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel11.setText("__________________________________________________________________________________________________________________________________________________________");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel11)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(278, 278, 278))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addContainerGap())
        );

        jPanel1.add(jPanel2, java.awt.BorderLayout.PAGE_START);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jTabbedPane1.setBackground(new java.awt.Color(15, 175, 25));
        jTabbedPane1.setForeground(new java.awt.Color(255, 255, 255));

        beranda.setBackground(new java.awt.Color(255, 255, 255));
        beranda.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        formLogin.setClosable(true);
        formLogin.setVisible(false);

        jPanel10.setBackground(new java.awt.Color(15, 175, 25));

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Login");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Username");

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Password");

        btnMasuk.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnMasuk.setText("Masuk");
        btnMasuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMasukActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(120, 120, 120)
                        .addComponent(jLabel20))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tfUser_Login)
                            .addComponent(jLabel21)
                            .addComponent(jLabel22)
                            .addComponent(btnMasuk, javax.swing.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE)
                            .addComponent(tfPw_Login))))
                .addContainerGap(67, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel20)
                .addGap(18, 18, 18)
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfUser_Login, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfPw_Login, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnMasuk)
                .addContainerGap(43, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout formLoginLayout = new javax.swing.GroupLayout(formLogin.getContentPane());
        formLogin.getContentPane().setLayout(formLoginLayout);
        formLoginLayout.setHorizontalGroup(
            formLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        formLoginLayout.setVerticalGroup(
            formLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        beranda.add(formLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 20, 320, 280));

        formRegister.setClosable(true);
        formRegister.setVisible(false);

        jPanel11.setBackground(new java.awt.Color(15, 175, 25));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Register");

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("Nama");

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Username");

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Password");

        jLabel27.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(255, 255, 255));
        jLabel27.setText("Jenis Kelamin");

        JK_Register.add(rbLk_Register);
        rbLk_Register.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        rbLk_Register.setForeground(new java.awt.Color(255, 255, 255));
        rbLk_Register.setText("Laki-Laki");

        JK_Register.add(rbPr_Register);
        rbPr_Register.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        rbPr_Register.setForeground(new java.awt.Color(255, 255, 255));
        rbPr_Register.setText("Perempuan");

        jLabel28.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("Alamat");

        taAlamat_Register.setColumns(20);
        taAlamat_Register.setRows(5);
        jScrollPane3.setViewportView(taAlamat_Register);

        jLabel29.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setText("No.HP *(Max 12 digit)");

        btnDaftar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnDaftar.setText("Daftar");
        btnDaftar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDaftarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel11Layout.createSequentialGroup()
                        .addGap(138, 138, 138)
                        .addComponent(jLabel23)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel11Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 289, Short.MAX_VALUE)
                            .addComponent(btnDaftar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tfPw_Register, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(tfNama_Register)
                            .addComponent(tfUser_Register)
                            .addComponent(tfHp_Register)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel27)
                                    .addComponent(jLabel26)
                                    .addComponent(jLabel25)
                                    .addComponent(jLabel24)
                                    .addGroup(jPanel11Layout.createSequentialGroup()
                                        .addComponent(rbLk_Register)
                                        .addGap(18, 18, 18)
                                        .addComponent(rbPr_Register))
                                    .addComponent(jLabel28)
                                    .addComponent(jLabel29))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(50, 50, 50))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfNama_Register, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfUser_Register, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfPw_Register, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbLk_Register)
                    .addComponent(rbPr_Register))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel29)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfHp_Register, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDaftar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout formRegisterLayout = new javax.swing.GroupLayout(formRegister.getContentPane());
        formRegister.getContentPane().setLayout(formRegisterLayout);
        formRegisterLayout.setHorizontalGroup(
            formRegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        formRegisterLayout.setVerticalGroup(
            formRegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        beranda.add(formRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 400, 480));

        LHalo.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        LHalo.setText("Halo");
        beranda.add(LHalo, new org.netbeans.lib.awtextra.AbsoluteConstraints(62, 80, -1, -1));

        LWellcome.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        LWellcome.setForeground(new java.awt.Color(15, 175, 25));
        LWellcome.setText("Nama");
        beranda.add(LWellcome, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 80, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("Platform yang menghubungkan Anda dengan kekayaan budaya Indonesia melalui produk tradisional yang unik dan autentik.");
        jLabel5.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        beranda.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 153, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 51, 51));
        jLabel6.setText("Kami berdedikasi untuk melestarikan warisan budaya Nusantara dengan menyediakan beragam barang tradisional, mulai dari");
        jLabel6.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        beranda.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 175, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 51, 51));
        jLabel7.setText("pakaian adat, kerajinan tangan, hingga alat musk dari berbagai daerah. Di TradisiWare, setiap produk tidak hanya mencerminkan");
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        beranda.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 197, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setText("kearifan lokal tetapi juga membawa cerita dari para pengrajin yang dengan cinta menciptakannya. Kami berharap, dengan");
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        beranda.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 219, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 51, 51));
        jLabel9.setText("hadirnya TradisiWare, masyarakat dapat lebih mengenal, mengapresiasi, dan mendukung budaya Indonesia. Bergabunglah");
        jLabel9.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        beranda.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 241, -1, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 51, 51));
        jLabel10.setText("bersama kami untuk merayakan keindahan tradisi dan menginspirasi generasi mendatang!");
        jLabel10.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        beranda.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 263, -1, -1));

        btnLihat_Produk.setBackground(new java.awt.Color(15, 175, 25));
        btnLihat_Produk.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnLihat_Produk.setForeground(new java.awt.Color(255, 255, 255));
        btnLihat_Produk.setText("Lihat Produk");
        btnLihat_Produk.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnLihat_Produk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLihat_ProdukActionPerformed(evt);
            }
        });
        beranda.add(btnLihat_Produk, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 300, -1, 44));

        btnLogin.setBackground(new java.awt.Color(15, 175, 25));
        btnLogin.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLogin.setForeground(new java.awt.Color(255, 255, 255));
        btnLogin.setText("Login");
        btnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginActionPerformed(evt);
            }
        });
        beranda.add(btnLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 10, -1, -1));

        btnRegister.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegister.setForeground(new java.awt.Color(51, 51, 51));
        btnRegister.setText("Register");
        btnRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegisterActionPerformed(evt);
            }
        });
        beranda.add(btnRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 10, -1, -1));

        jLabel39.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel39.setText("Selamat Datang di,");
        beranda.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(62, 113, -1, -1));

        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(15, 175, 25));
        jLabel40.setText("TradisiWare");
        beranda.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(283, 113, -1, -1));

        jTabbedPane1.addTab("Beranda", beranda);

        produk.setBackground(new java.awt.Color(255, 255, 255));
        produk.setLayout(new java.awt.BorderLayout());

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setPreferredSize(new java.awt.Dimension(770, 50));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cbJenis_Produk.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Semua", "Pakaian", "Kerajinan Tangan", "Alat Musik" }));
        cbJenis_Produk.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbJenis_ProdukItemStateChanged(evt);
            }
        });
        jPanel8.add(cbJenis_Produk, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 10, 120, -1));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setText("__________________________________________________________________________________________________________________________________________________________");
        jPanel8.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, -1, 20));

        produk.add(jPanel8, java.awt.BorderLayout.PAGE_START);

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        detailProduk.setClosable(true);
        detailProduk.setVisible(false);

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));
        jPanel13.setLayout(new java.awt.BorderLayout());

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel37.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel37.setText("Detail");
        jPanel4.add(jLabel37);

        jLabel38.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(15, 175, 25));
        jLabel38.setText("Produk");
        jPanel4.add(jLabel38);

        jPanel13.add(jPanel4, java.awt.BorderLayout.PAGE_START);

        jPanel6.setBackground(new java.awt.Color(15, 175, 25));

        LNama_Produk.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        LNama_Produk.setForeground(new java.awt.Color(255, 255, 255));
        LNama_Produk.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LNama_Produk.setText("Nama Produk");

        LGambar_Produk.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LGambar_Produk.setPreferredSize(new java.awt.Dimension(210, 130));

        taDetail_Produk.setEditable(false);
        taDetail_Produk.setColumns(20);
        taDetail_Produk.setLineWrap(true);
        taDetail_Produk.setMaximumSize(new java.awt.Dimension(232, 2147483647));
        taDetail_Produk.setMinimumSize(new java.awt.Dimension(232, 20));
        taDetail_Produk.setPreferredSize(new java.awt.Dimension(232, 85));
        jScrollPane1.setViewportView(taDetail_Produk);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 376, Short.MAX_VALUE)
                    .addComponent(LGambar_Produk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(LNama_Produk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(LNama_Produk)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(LGambar_Produk, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jPanel13.add(jPanel6, java.awt.BorderLayout.CENTER);

        javax.swing.GroupLayout detailProdukLayout = new javax.swing.GroupLayout(detailProduk.getContentPane());
        detailProduk.getContentPane().setLayout(detailProdukLayout);
        detailProdukLayout.setHorizontalGroup(
            detailProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        detailProdukLayout.setVerticalGroup(
            detailProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(detailProdukLayout.createSequentialGroup()
                .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        jPanel7.add(detailProduk, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 400, 470));

        beliProduk.setClosable(true);
        beliProduk.setVisible(false);
        beliProduk.addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
                beliProdukInternalFrameClosing(evt);
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
            }
        });

        jPanel20.setBackground(new java.awt.Color(15, 175, 25));

        jLabel42.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("Pembelian Produk");

        jLabel43.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("Nama Produk");

        jLabel44.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(255, 255, 255));
        jLabel44.setText("Harga");

        tfNama_Beli.setEditable(false);

        btnBeli.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBeli.setText("Beli");
        btnBeli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBeliActionPerformed(evt);
            }
        });

        namaVarian.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        namaVarian.setForeground(new java.awt.Color(255, 255, 255));
        namaVarian.setText("Bahan / Ukuran");

        tfHarga_Beli.setEditable(false);

        jLabel47.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(255, 255, 255));
        jLabel47.setText("Jumlah");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel42)
                .addGap(86, 86, 86))
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                        .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(namaVarian)
                            .addComponent(jLabel44)
                            .addComponent(jLabel43))
                        .addContainerGap(258, Short.MAX_VALUE))
                    .addGroup(jPanel20Layout.createSequentialGroup()
                        .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel47)
                            .addComponent(btnBeli, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                            .addComponent(tfNama_Beli)
                            .addComponent(tfHarga_Beli)
                            .addComponent(tfJumlah_Beli)
                            .addComponent(cbNilaiVarian, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel42)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel43)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfNama_Beli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel44)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfHarga_Beli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(namaVarian)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbNilaiVarian, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(jLabel47)
                .addGap(7, 7, 7)
                .addComponent(tfJumlah_Beli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnBeli)
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout beliProdukLayout = new javax.swing.GroupLayout(beliProduk.getContentPane());
        beliProduk.getContentPane().setLayout(beliProdukLayout);
        beliProdukLayout.setHorizontalGroup(
            beliProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel20, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        beliProdukLayout.setVerticalGroup(
            beliProdukLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel7.add(beliProduk, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 400, 360));

        tblDaftar_Produk.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Nama Produk", "Harga", "Status"
            }
        ));
        tblDaftar_Produk.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblDaftar_ProdukMouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(tblDaftar_Produk);

        jPanel7.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 59, 758, 331));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel19.setText("Daftar");
        jPanel7.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 10, -1, -1));

        jLabel51.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(15, 175, 25));
        jLabel51.setText("Produk");
        jPanel7.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 10, -1, -1));

        btnDetail_Produk.setBackground(new java.awt.Color(15, 175, 25));
        btnDetail_Produk.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnDetail_Produk.setForeground(new java.awt.Color(255, 255, 255));
        btnDetail_Produk.setText("Detail");
        btnDetail_Produk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDetail_ProdukActionPerformed(evt);
            }
        });
        jPanel7.add(btnDetail_Produk, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 410, -1, -1));

        btnBeli_Produk.setBackground(new java.awt.Color(15, 175, 25));
        btnBeli_Produk.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBeli_Produk.setForeground(new java.awt.Color(255, 255, 255));
        btnBeli_Produk.setText("Beli");
        btnBeli_Produk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBeli_ProdukActionPerformed(evt);
            }
        });
        jPanel7.add(btnBeli_Produk, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 410, -1, -1));

        produk.add(jPanel7, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("Produk", produk);

        riwayat.setBackground(new java.awt.Color(255, 255, 255));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setText("Riwayat");

        jLabel41.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(15, 175, 25));
        jLabel41.setText("Pembelian");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel41)
                .addContainerGap(280, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel41))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tblRiwayat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID Pembelian", "Nama Produk", "Harga Satuan", "Jumlah", "Bahan/Ukuran", "Total Harga"
            }
        ));
        jScrollPane10.setViewportView(tblRiwayat);

        javax.swing.GroupLayout riwayatLayout = new javax.swing.GroupLayout(riwayat);
        riwayat.setLayout(riwayatLayout);
        riwayatLayout.setHorizontalGroup(
            riwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(riwayatLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 758, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(riwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, riwayatLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        riwayatLayout.setVerticalGroup(
            riwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(riwayatLayout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
            .addGroup(riwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, riwayatLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(450, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Riwayat Pembelian", riwayat);

        profil.setBackground(new java.awt.Color(255, 255, 255));
        profil.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        editProfil.setClosable(true);
        editProfil.setVisible(false);

        jPanel12.setBackground(new java.awt.Color(15, 175, 25));

        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("Edit Profil");

        jLabel31.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("Nama");

        jLabel32.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("Username");

        jLabel33.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("Password");

        jLabel34.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("Jenis Kelamin");

        JenisKelamin.add(rbLk_Edit);
        rbLk_Edit.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        rbLk_Edit.setForeground(new java.awt.Color(255, 255, 255));
        rbLk_Edit.setText("Laki-Laki");

        JenisKelamin.add(rbPr_Edit);
        rbPr_Edit.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        rbPr_Edit.setForeground(new java.awt.Color(255, 255, 255));
        rbPr_Edit.setText("Perempuan");

        jLabel35.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("Alamat");

        taAlamat_Edit.setColumns(20);
        taAlamat_Edit.setLineWrap(true);
        taAlamat_Edit.setRows(5);
        jScrollPane4.setViewportView(taAlamat_Edit);

        jLabel36.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("No.HP");

        btnEdit.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEdit.setText("Edit");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel12Layout.createSequentialGroup()
                        .addGap(138, 138, 138)
                        .addComponent(jLabel30)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel12Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 289, Short.MAX_VALUE)
                            .addComponent(btnEdit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tfPw_Edit, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(tfNama_Edit)
                            .addComponent(tfUser_Edit)
                            .addComponent(tfHp_Edit)
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel34)
                                    .addComponent(jLabel33)
                                    .addComponent(jLabel32)
                                    .addComponent(jLabel31)
                                    .addGroup(jPanel12Layout.createSequentialGroup()
                                        .addComponent(rbLk_Edit)
                                        .addGap(18, 18, 18)
                                        .addComponent(rbPr_Edit))
                                    .addComponent(jLabel35)
                                    .addComponent(jLabel36))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(50, 50, 50))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel31)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfNama_Edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel32)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfUser_Edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel33)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfPw_Edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel34)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbLk_Edit)
                    .addComponent(rbPr_Edit))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel35)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel36)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfHp_Edit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnEdit)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout editProfilLayout = new javax.swing.GroupLayout(editProfil.getContentPane());
        editProfil.getContentPane().setLayout(editProfilLayout);
        editProfilLayout.setHorizontalGroup(
            editProfilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        editProfilLayout.setVerticalGroup(
            editProfilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        profil.add(editProfil, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 0, 400, 490));

        LGambar_Profil.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projekakhir_pemvis/profil2.png"))); // NOI18N
        LGambar_Profil.setMaximumSize(new java.awt.Dimension(120, 100));
        LGambar_Profil.setMinimumSize(new java.awt.Dimension(120, 100));
        LGambar_Profil.setPreferredSize(new java.awt.Dimension(120, 100));
        profil.add(LGambar_Profil, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 30, 130, -1));

        jLabel13.setText("Nama");
        profil.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 18, -1, -1));

        tfNama_Profil.setEditable(false);
        profil.add(tfNama_Profil, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 40, 300, -1));

        jLabel14.setText("Username");
        profil.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 68, -1, -1));

        tfUser_Profil.setEditable(false);
        profil.add(tfUser_Profil, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 90, 300, -1));

        jLabel15.setText("Password");
        profil.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 118, -1, -1));

        jLabel16.setText("Jenis Kelamin");
        profil.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 168, -1, -1));

        tfJK_Profil.setEditable(false);
        profil.add(tfJK_Profil, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 190, 300, -1));

        jLabel17.setText("Alamat");
        profil.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 218, -1, -1));

        jLabel18.setText("No.HP");
        profil.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 389, -1, -1));

        tfHp_Profil.setEditable(false);
        profil.add(tfHp_Profil, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 411, 300, -1));

        taAlamat_Profil.setEditable(false);
        taAlamat_Profil.setColumns(20);
        taAlamat_Profil.setLineWrap(true);
        taAlamat_Profil.setRows(5);
        jScrollPane2.setViewportView(taAlamat_Profil);

        profil.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 240, 300, 143));

        btnEdit_Profil.setBackground(new java.awt.Color(15, 175, 25));
        btnEdit_Profil.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnEdit_Profil.setForeground(new java.awt.Color(255, 255, 255));
        btnEdit_Profil.setText("Edit");
        btnEdit_Profil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEdit_ProfilActionPerformed(evt);
            }
        });
        profil.add(btnEdit_Profil, new org.netbeans.lib.awtextra.AbsoluteConstraints(509, 445, -1, -1));

        tfPw_Profil.setEditable(false);
        profil.add(tfPw_Profil, new org.netbeans.lib.awtextra.AbsoluteConstraints(178, 140, 300, -1));

        btnLogout.setBackground(new java.awt.Color(15, 175, 25));
        btnLogout.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLogout.setForeground(new java.awt.Color(255, 255, 255));
        btnLogout.setText("Logout");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });
        profil.add(btnLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 10, -1, -1));

        jTabbedPane1.addTab("Profil", profil);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 547, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(jPanel3, java.awt.BorderLayout.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 639, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLihat_ProdukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLihat_ProdukActionPerformed
        if (userLogin == null) {
            formLogin.setVisible(true);
        } else {        
            jTabbedPane1.setSelectedIndex(1);
        }
    }//GEN-LAST:event_btnLihat_ProdukActionPerformed

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
        formLogin.setVisible(true);
    }//GEN-LAST:event_btnLoginActionPerformed

    private void btnRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegisterActionPerformed
        formRegister.setVisible(true);
    }//GEN-LAST:event_btnRegisterActionPerformed

    private void btnEdit_ProfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEdit_ProfilActionPerformed
        editProfil.setVisible(true);
    }//GEN-LAST:event_btnEdit_ProfilActionPerformed

    private void btnDetail_ProdukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDetail_ProdukActionPerformed
        if (produkDetail == null) {
            JOptionPane.showMessageDialog(null, "Pilih Produk Terlebih Dahulu", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
        } else {
            detailProduk.setVisible(true);
            LNama_Produk.setText(produkDetail.getNama_Produk());
            LGambar_Produk.setIcon(new javax.swing.ImageIcon(getClass().getResource("../gambar/" + produkDetail.getGambar())));
            taDetail_Produk.setText("");
            taDetail_Produk.setText(
                "Produk : " + produkDetail.getNama_Produk() + "\n" +
                "Harga : Rp." + produkDetail.getHarga() + "\n" +
                "Deskripsi : \n" + produkDetail.getDeskripsi()
            );
        }
        
    }//GEN-LAST:event_btnDetail_ProdukActionPerformed

    private void btnBeli_ProdukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBeli_ProdukActionPerformed
        if (produkDetail == null) {
            JOptionPane.showMessageDialog(null, "Pilih Produk Terlebih Dahulu", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
        } else {
            beliProduk.setVisible(true);
            tfNama_Beli.setText(produkDetail.getNama_Produk());
            tfHarga_Beli.setText(Double.toString(produkDetail.getHarga()));
            List<VarianProduk> vaproList = VarianProduk.getVaProById_produk(produkDetail.getId());
            String nV = "";
            for (VarianProduk vapro : vaproList) {    
                nV = vapro.getAtribut_nama();
                cbNilaiVarian.addItem(vapro.getAtribut_nilai());
                
            }
            namaVarian.setText(nV);
        }
    }//GEN-LAST:event_btnBeli_ProdukActionPerformed

    private void btnDaftarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDaftarActionPerformed
        String nama = tfNama_Register.getText();
        String username = tfUser_Register.getText();
        String password = new String(tfPw_Register.getPassword());
        String jenis_kelamin = "";
        if (rbLk_Register.isSelected()) {
            jenis_kelamin = "Laki-Laki";
        } else {
            jenis_kelamin = "Perempuan";
        }
        String alamat = taAlamat_Register.getText();
        String no_hp = tfHp_Register.getText();
        
        try {
            if(nama.isEmpty() || username.isEmpty() || password.isEmpty() || jenis_kelamin.isEmpty() || alamat.isEmpty() || no_hp.isEmpty()){
                JOptionPane.showMessageDialog(null, "Data Tidak Boleh Kosong", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
            } else {
                if (User.cariUsername(username) == null) {
                    int no_hp2 = Integer.parseInt(no_hp);
                    int password2 = Integer.parseInt(password);
                    boolean hasil = User.tambahUser(nama, username, password2, jenis_kelamin, alamat, no_hp);
                    if (hasil) {
                        JOptionPane.showMessageDialog(null, "Register Berhasil", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
                        formLogin.setVisible(true);
                        formRegister.setVisible(false);
                    } else {
                        JOptionPane.showMessageDialog(null, "Register Gagal", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Username Sudah Ada", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Masukkan Data Dengan Benar!", "Peringatan", JOptionPane.ERROR_MESSAGE);
        }
        
    }//GEN-LAST:event_btnDaftarActionPerformed

    private void btnMasukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMasukActionPerformed
        String username = tfUser_Login.getText();
        String password = new String(tfPw_Login.getPassword());
        try {
            if (username.equals("admin")) {
                User hasil = User.loginAdmin(username, password);
                if (hasil != null) {
                    JOptionPane.showMessageDialog(null, "Login Berhasil", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
                    new Admin().setVisible(true);
                    this.dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Login Gagal! \nData Tidak Ditemukan", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                if(username.isEmpty() || password.isEmpty()){
                    JOptionPane.showMessageDialog(null, "Data Tidak Boleh Kosong", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    int password2 = Integer.parseInt(password);
                    User hasil = User.cariUsername(username);
                    if (hasil != null && hasil.getPassword() == password2) {
                        JOptionPane.showMessageDialog(null, "Login Berhasil", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
                        formLogin.setVisible(false);
                        userLogin = new User(hasil.getId(), hasil.getNama(), hasil.getUsername(), hasil.getPassword(), hasil.getJenis_kelamin(), hasil.getAlamat(), hasil.getNo_hp());
                        loadDataDaftar_Produk("");
                        loadDataRiwayat_Pembelian();
                        loadDataUser();
                        page();
                        btnLogin.setVisible(false);
                        btnRegister.setVisible(false);
                        LHalo.setText("Halo");
                        LWellcome.setText(username);
                    } else {
                        JOptionPane.showMessageDialog(null, "Login Gagal! \nData Tidak Ditemukan", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Masukkan Data Dengan Benar!", "Peringatan", JOptionPane.ERROR_MESSAGE);
            System.out.println(e);
        }
        
    }//GEN-LAST:event_btnMasukActionPerformed

    private void tblDaftar_ProdukMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDaftar_ProdukMouseClicked
        int row = tblDaftar_Produk.rowAtPoint(evt.getPoint());
        String nama = (String) tblDaftar_Produk.getValueAt(row, 0);
        produkDetail = Produk.getByNama(nama);
    }//GEN-LAST:event_tblDaftar_ProdukMouseClicked

    private void btnBeliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBeliActionPerformed
        int jumlah = Integer.parseInt(tfJumlah_Beli.getText());
        int total = (int) (jumlah * produkDetail.getHarga());
        String bayar = JOptionPane.showInputDialog(null, "Nominal Yang Harus DiBayar Rp. " + total + "\nBayar : ", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
        int bayar2 = Integer.parseInt(bayar);   
        while(bayar == null || bayar.isEmpty()){
            JOptionPane.showMessageDialog(null, "Nominal Pembayaran Tidak Boleh Kosong", "Peringatan", JOptionPane.ERROR_MESSAGE);
            bayar = JOptionPane.showInputDialog(null, "Nominal Yang Harus DiBayar Rp. " + total + "\nBayar : ", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
        }
        System.out.println(produkDetail.getId());
        if (bayar2 < total) {
            JOptionPane.showMessageDialog(null, "Nominal Terlalu Kecil \nHarap Membayar Dengan Uang Pas", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
        } else if (bayar2 > total) {
            JOptionPane.showMessageDialog(null, "Nominal Terlalu Besar \nHarap Membayar Dengan Uang Pas", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
        } else {
            boolean hasil1 = Transaksi.tambahTransaksi(userLogin.getId(), total);
            Transaksi lastData = Transaksi.getLastData();
            VarianProduk vp = VarianProduk.getVaProById_produkNilai(produkDetail.getId(), cbNilaiVarian.getSelectedItem().toString());
            boolean hasil2 = DetailTransaksi.tambahDetail_Transaksi(lastData.getId(), vp.getId(), jumlah);
            loadDataRiwayat_Pembelian();
            reset();
            beliProduk.setVisible(false);
        }
    }//GEN-LAST:event_btnBeliActionPerformed

    private void cbJenis_ProdukItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbJenis_ProdukItemStateChanged
        loadDataDaftar_Produk(cbJenis_Produk.getSelectedItem().toString());
    }//GEN-LAST:event_cbJenis_ProdukItemStateChanged

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
        String nama = tfNama_Edit.getText();
        String username = tfUser_Edit.getText();
        String password = new String(tfPw_Edit.getPassword());
        String jenis_kelamin = "";
        if (rbLk_Edit.isSelected()) {
            jenis_kelamin = "Laki-Laki";
        } else {
            jenis_kelamin = "Perempuan";
        }
        String alamat = taAlamat_Edit.getText();
        String no_hp = tfHp_Edit.getText();
        
        try {
            if(nama.isEmpty() || username.isEmpty() || password.isEmpty() || jenis_kelamin.isEmpty() || alamat.isEmpty() || no_hp.isEmpty()){
                JOptionPane.showMessageDialog(null, "Data Tidak Boleh Kosong", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
            } else {
                if (User.cariUsername(username) == null) {
                    int no_hp2 = Integer.parseInt(no_hp);
                    int password2 = Integer.parseInt(password);
                    boolean hasil = User.editUser(userLogin.getId(), nama, username, password2, jenis_kelamin, alamat, no_hp);
                    if (hasil) {
                        JOptionPane.showMessageDialog(null, "Edit Profil Berhasil");
                        userLogin = new User(userLogin.getId(), nama, username, password2, jenis_kelamin, alamat, no_hp);
                        loadDataUser();
                        editProfil.setVisible(false);
                    } else {
                        JOptionPane.showMessageDialog(null, "Edit Profil Gagal");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Username Sudah Ada", "Perhatian", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Masukkan Data Dengan Benar!", "Peringatan", JOptionPane.ERROR_MESSAGE);
        }
        
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        int pilihan = JOptionPane.showConfirmDialog(null, "Yakin Ingin Logout?", "Perhatian", JOptionPane.OK_CANCEL_OPTION);
        if(pilihan == JOptionPane.OK_OPTION){
            userLogin = null;
            page();
            jTabbedPane1.setSelectedIndex(0);
            btnLogin.setVisible(true);
            btnRegister.setVisible(true);
            LHalo.setText("");
            LWellcome.setText("");
            reset();
        }
        
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void beliProdukInternalFrameClosing(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_beliProdukInternalFrameClosing
        cbNilaiVarian.removeAllItems();
    }//GEN-LAST:event_beliProdukInternalFrameClosing
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TradisiWare.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TradisiWare.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TradisiWare.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TradisiWare.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TradisiWare().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup JK_Register;
    private javax.swing.ButtonGroup JenisKelamin;
    private javax.swing.JLabel LGambar_Produk;
    private javax.swing.JLabel LGambar_Profil;
    private javax.swing.JLabel LHalo;
    private javax.swing.JLabel LNama_Produk;
    private javax.swing.JLabel LWellcome;
    private javax.swing.JInternalFrame beliProduk;
    private javax.swing.JPanel beranda;
    private javax.swing.JButton btnBeli;
    private javax.swing.JButton btnBeli_Produk;
    private javax.swing.JButton btnDaftar;
    private javax.swing.JButton btnDetail_Produk;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnEdit_Profil;
    private javax.swing.JButton btnLihat_Produk;
    private javax.swing.JButton btnLogin;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnMasuk;
    private javax.swing.JButton btnRegister;
    private javax.swing.JComboBox<String> cbJenis_Produk;
    private javax.swing.JComboBox<String> cbNilaiVarian;
    private javax.swing.JInternalFrame detailProduk;
    private javax.swing.JInternalFrame editProfil;
    private javax.swing.JInternalFrame formLogin;
    private javax.swing.JInternalFrame formRegister;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel namaVarian;
    private javax.swing.JPanel produk;
    private javax.swing.JPanel profil;
    private javax.swing.JRadioButton rbLk_Edit;
    private javax.swing.JRadioButton rbLk_Register;
    private javax.swing.JRadioButton rbPr_Edit;
    private javax.swing.JRadioButton rbPr_Register;
    private javax.swing.JPanel riwayat;
    private javax.swing.JTextArea taAlamat_Edit;
    private javax.swing.JTextArea taAlamat_Profil;
    private javax.swing.JTextArea taAlamat_Register;
    private javax.swing.JTextArea taDetail_Produk;
    private javax.swing.JTable tblDaftar_Produk;
    private javax.swing.JTable tblRiwayat;
    private javax.swing.JTextField tfHarga_Beli;
    private javax.swing.JTextField tfHp_Edit;
    private javax.swing.JTextField tfHp_Profil;
    private javax.swing.JTextField tfHp_Register;
    private javax.swing.JTextField tfJK_Profil;
    private javax.swing.JTextField tfJumlah_Beli;
    private javax.swing.JTextField tfNama_Beli;
    private javax.swing.JTextField tfNama_Edit;
    private javax.swing.JTextField tfNama_Profil;
    private javax.swing.JTextField tfNama_Register;
    private javax.swing.JPasswordField tfPw_Edit;
    private javax.swing.JPasswordField tfPw_Login;
    private javax.swing.JPasswordField tfPw_Profil;
    private javax.swing.JPasswordField tfPw_Register;
    private javax.swing.JTextField tfUser_Edit;
    private javax.swing.JTextField tfUser_Login;
    private javax.swing.JTextField tfUser_Profil;
    private javax.swing.JTextField tfUser_Register;
    // End of variables declaration//GEN-END:variables
}
